﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BadgerysCreekHotel.Models.ViewModels
{
    public class BookingStat
    {
        public int RoomID { get; set; }
        public int NumOfBooking { get; set; }
    }
}
