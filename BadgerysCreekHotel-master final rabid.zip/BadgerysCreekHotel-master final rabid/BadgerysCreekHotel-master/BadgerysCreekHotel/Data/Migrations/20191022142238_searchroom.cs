﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BadgerysCreekHotel.Data.Migrations
{
    public partial class searchroom : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            
        }
    }
}
