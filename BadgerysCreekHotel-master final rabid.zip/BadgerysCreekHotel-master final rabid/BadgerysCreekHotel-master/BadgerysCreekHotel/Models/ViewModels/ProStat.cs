﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BadgerysCreekHotel.Models.ViewModels
{
    public class ProStat
    {
        public string PostCode { get; set; }
        public int NumOfCustomer { get; set; }
        //public int RoomID { get; set; }
        //public int NumOfBooking { get; set; }
    }
}
